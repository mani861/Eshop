package com.upgrad.eshop.services;

public interface EshopOrderService {
}
